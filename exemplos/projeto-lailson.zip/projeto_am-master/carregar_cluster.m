if not(exist('min_C', 'var'))
  load cluster.mat
end