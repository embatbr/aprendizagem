if not(exist('X', 'var'))
  load dados.mat
end