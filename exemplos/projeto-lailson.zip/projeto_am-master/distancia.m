function d = distancia(x1, x2)
  d = sqrt(sum((x1 - x2).^2));
end

